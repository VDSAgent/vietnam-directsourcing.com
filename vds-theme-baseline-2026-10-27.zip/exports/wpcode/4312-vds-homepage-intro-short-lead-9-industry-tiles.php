/**
 * VDS - Homepage intro: short lead + 9 industry tiles   [v1, 26 Oct 2026]
 *
 * The knowledge theme's home-tpl.php hard-codes a long 'Your Trusted Sourcing Partner in Vietnam' block
 * (section.vds-intro-area) that only listed 8 categories. This replaces that block, in the final front-end
 * HTML, with a short lead and nine plain (non-linked) industry tiles. The theme file is NOT edited.
 * Styling: Additional CSS block 'VDS homepage intro' (.vds-intro-grid ...). Source: Website/Homepage/ in the project folder.
 * Reversible: toggle this snippet Inactive and the original text returns.
 */

if ( ! function_exists( 'vds_home_intro_grid' ) ) {
	function vds_home_intro_grid( $html ) {

		if ( is_admin() || ! is_string( $html ) || false === strpos( $html, 'vds-intro-area' ) ) {
			return $html;
		}

		// Already replaced (the filter can run twice in one request). Look for the new section's own <ul>,
		// NOT for the class name: 'vds-intro-grid' also appears in the Additional CSS in the page head.
		if ( false !== strpos( $html, "<ul class='vds-cat-grid'>" ) ) {
			return $html;
		}

		$new = <<<'HTMLEND'
<section class='vds-intro-area vds-intro-grid pt-100 pb-60 pt-md-60 pb-md-40 pt-xs-60 pb-xs-40'><div class='container'><div class='row justify-content-center'><div class='col-xl-10 col-lg-11'><div class='section-title text-center mb-25'><h2>Your Trusted Sourcing Partner in Vietnam</h2></div><p class='vds-intro-lead'>We help international buyers find, vet and manage factories across Vietnam.<br>No middlemen, no retainer.</p><ul class='vds-cat-grid'><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="14" y="8" width="9" height="50" rx="3"/><path d="M14 22h9M14 36h9M14 49h9"/><rect x="31" y="20" width="9" height="38" rx="3"/><path d="M31 33h9M31 46h9"/></g><path d="M43 24c1-8 7-13 15-13 0 8-6 14-15 13z" fill="#E3A23A" stroke="#E3A23A" stroke-width="1.5" stroke-linejoin="round"/><path d="M43 24l8-6" fill="none" stroke="#fff" stroke-width="1.4" stroke-linecap="round"/></svg><strong>Bamboo &amp; Wood</strong><span>Furniture, homewares</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13 22h38l4 33H9z"/><path d="M23 22v-4a9 9 0 0 1 18 0v4"/></g><path d="M23 47c0-9 6-13 18-13 0 9-7 15-18 13z" fill="#E3A23A" stroke="#E3A23A" stroke-width="1.5" stroke-linejoin="round"/><path d="M23 47l9-8" fill="none" stroke="#fff" stroke-width="1.4" stroke-linecap="round"/></svg><strong>Biodegradable Plastic &amp; Paper</strong><span>Eco packaging, tableware</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><rect x="19.5" y="26" width="18" height="12" fill="#E3A23A" opacity=".9"/><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="14" width="48" height="38" rx="3"/><path d="M8 26h48M8 39h48M30 14v12M19 26v13M41 26v13M30 39v13"/></g></svg><strong>Construction Materials</strong><span>Tiles, stone, fixtures</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="46" height="46" rx="11"/></g><path d="M32 19v26M19 32h26" fill="none" stroke="#E3A23A" stroke-width="6" stroke-linecap="round"/></svg><strong>Health Care</strong><span>Medical supplies</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 9L7 17l6 12 7-3v29h24V26l7 3 6-12-15-8c-2 5-6 8-10 8s-8-3-10-8z"/></g><path d="M26 47c0-7 4-11 12-11 0 7-5 12-12 11z" fill="#E3A23A" stroke="#E3A23A" stroke-width="1.5" stroke-linejoin="round"/></svg><strong>Organic Textiles</strong><span>Organic fabric, apparel</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 54l9-24h37l-7 24z"/><path d="M13 42h37M28 30l-3 24M41 30l-2 24"/></g><g fill="none" stroke="#E3A23A" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="47" cy="15" r="6"/><path d="M47 3v3M47 24v3M35 15h3M56 15h3M38.5 6.5l2 2M55.5 6.5l-2 2"/></g></svg><strong>Renewable Energy</strong><span>Solar racking, components</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13 12h38v9h-14v22h14v9H13v-9h14V21H13z"/></g><circle cx="22" cy="16.5" r="1.8" fill="#E3A23A"/><circle cx="42" cy="16.5" r="1.8" fill="#E3A23A"/><circle cx="22" cy="47.5" r="1.8" fill="#E3A23A"/><circle cx="42" cy="47.5" r="1.8" fill="#E3A23A"/></svg><strong>Steel &amp; Metal</strong><span>Fabrication, structural</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="17" y="17" width="30" height="30" rx="4"/><path d="M25 9v8M32 9v8M39 9v8M25 47v8M32 47v8M39 47v8M9 25h8M9 32h8M9 39h8M47 25h8M47 32h8M47 39h8"/></g><rect x="26" y="26" width="12" height="12" rx="2" fill="none" stroke="#E3A23A" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg><strong>Electronic Components</strong><span>PCBs, assemblies</span></li><li><svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true" focusable="false"><g fill="none" stroke="#16243D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13 9h9v8l5 7v31H8V24l5-7z" transform="translate(2 0)"/><path d="M15 15h9" /></g><g fill="none" stroke="#E3A23A" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="38" y="33" width="19" height="22" rx="2"/><path d="M38 41h19"/></g></svg><strong>FMCG &amp; Consumer Goods</strong><span>Food, personal care</span></li></ul><p class='vds-intro-caption'>Local team in Hanoi, Da Nang and Ho Chi Minh City. Original factory pricing, no hidden fees.</p></div></div></div></section>
HTMLEND;

		$out = preg_replace_callback(
			'#<section class=[\'"]vds-intro-area[^>]*>.*?</section>#s',
			function () use ( $new ) {
				return $new;
			},
			$html,
			1
		);

		// Only accept the result if the regex ran cleanly.
		return ( is_string( $out ) && '' !== $out ) ? $out : $html;
	}
}

add_filter( 'litespeed_buffer_before', 'vds_home_intro_grid' );
add_filter( 'wp_template_enhancement_output_buffer', 'vds_home_intro_grid' );
