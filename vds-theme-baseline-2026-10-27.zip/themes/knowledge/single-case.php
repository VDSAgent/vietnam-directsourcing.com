<?php
/*
// Template Name: Case Template
*/
get_header();
$author_id = $post->post_author;
?>    
        <!--slider-area start-->
        <section class="page-title-area page-title-3 sky-blue-bg pt-280 pb-130 pt-lg-200 pt-md-160 pb-md-120 pt-xs-160 pb-xs-90">
            <img class="page-shape shape_01 case-shape-3 d-none d-xxl-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/line/line-13.png" alt="Page Shape">
            <img class="page-shape shape_04 d-none d-md-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/shape/orange-1.svg" alt="Page Shape">
            <img class="page-shape shape_05 d-none d-xxl-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/shape/round-line-a.svg" alt="Page Shape">
            <img class="page-shape shape_06 d-none d-lg-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/shape/berry-1.svg" alt="Page Shape">
            <img class="page-shape shape_08 d-none d-xl-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/shape/dot-a.svg" alt="Page Shape">
            <img class="page-shape shape_09 d-none d-lg-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/case/case-plane.svg" alt="Page Shape">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-10">
                        <div class="page-title-wrapper text-center">
                            <h4 class="styled-text theme-color mb-30"> The warehouse of Mahfuz</h4>
                            <h1 class="h1 page-title mb-35">The power of inventory and fast delivery</h1>
                            <p class="fs-20 heding-color">When it comes to refrigeration technology, having a system that runs properly is essential in order t1 1prevent product loss.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--slider-area end-->
        <!--case-single-wrapper start-->
        <section class="case-single-wrapper position-relative pt-120 pb-105 pt-lg-80 pt-md-60 pt-xs-60 pb-lg-50 pb-md-30 pb-xs-30">
            <img class="case-single-shape cshape-1 d-none d-xl-inline-block" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/line/line-10.png" alt="">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-4">
                        <div class="single-widget-area sticky-top">
                            <?php if (is_active_sidebar('single-case-sidebar')) : ?>
                                <?php dynamic_sidebar('single-case-sidebar'); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-8">
                        <div class="case-single-content">
                            <img class="w-100 mb-45" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/case/case-10.jpg" alt="Case Img">
                            <h2 class="case-single-title mb-35">Efficiency, error reduction and a vital workplace</h2>
                            <p class="mb-4">We have the capability to tailor solutions for individual businesses by moulding our comprehensive range of services. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum </p>
                            <p class="mb-60">Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident,</p>
                            <div class="row align-items-center case-strategy-content mb-35">
                                <div class="col-lg-7 mb-30">
                                    <h2 class="case-single-title mb-4">Case Strategy</h2>
                                    <p class="mb-20">We have the capability to tailor solutions for individual businesses by moulding our comprehensive range of</p>
                                    <p class="mb-30">It is a long established fact that a reader will be distracted by the readable content</p>
                                    <ul class="list-style-none added-list">
                                        <li>Inventory Management</li>
                                        <li>Short Term Storage</li>
                                        <li>Shrink Wrapping</li>
                                        <li>Cargo Security Management</li>
                                    </ul>
                                </div>
                                <div class="col-lg-5 mb-30">
                                    <div class="strategy-img">
                                        <img class="w-100" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/case/case-11.jpg" alt="Strategy Img">
                                    </div>
                                </div>
                            </div>
                            <div class="shipment-time assistant-accesories mb-20">
                                <div class="box-one mb-30">
                                    <h3 class="fw-semibold">Surface area</h3>
                                    <h4 class="h2 box-title mb-0 lh-1">262 m2</h4>
                                    <p>AutoStore surface area</p>
                                </div>
                                <div class="box-one box-2 mb-30">
                                    <h3 class="fw-semibold">Number of robots</h3>
                                    <h4 class="h2 box-title mb-0 lh-1">7/8</h4>
                                    <p>Number of robots</p>
                                </div>
                                <div class="box-one box-3 mb-30">
                                    <h3 class="fw-semibold">Storage boxes</h3>
                                    <h4 class="h2 box-title mb-0 lh-1">10.939</h4>
                                    <p>Number of boxes</p>
                                </div>
                             </div>
                             <h2 class="case-single-title mb-25">A total solution from one supplier</h2>
                             <p class="mb-20">With its wide variety of brands on offer, Beijer Ref is the specialist wholesaler in cooling technology in the Netherlands. Everything from climate control technology and industrial refrigeration to comfort cooling.</p>
                             <p class="mb-20">In 2020, the head office in Sweden called for all the back office activities of its four sister companies to be centralised. These activities have been centralised in Oirschot since 2018. “We were bursting at the seams in our previous buildings”, said Erwin van Dijk, Director of Logistics and Operations at Beijer Ref in Oirschot.</p>
                             <p class="mb-40"> “I began by requesting quotations from several suppliers for the various sections of our warehouse. The Reesink group was able to provide us with a solution for all of our issues.That was the deciding factor for us.” </p>
                             <h2 class="case-single-title mb-25">Project Result</h2>
                             <p class="mb-70">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, natus numquam unde qui pariatur porro necessitatibus harum libero commodi rem veritatis in nisi vero odit tenetur esse quidem inventore ex.  Sunt nam mollitia, accusantium voluptates</p>
                             <div class="row align-items-center project-manager">
                                 <div class="col-xl-6 col-lg-7 col-md-7 d-sm-flex align-items-center mb-30">
                                     <img class="pr-manager mr-10" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/case/case-12.jpg" alt="Project Manager">
                                    <div class="designation-text">
                                        <h4 class="sec-title fw-medium mb-1"><?php echo get_the_author_meta( 'nicename', $author_id ); ?></h4>
                                        <p>Project manager at Logistic Solutions</p>
                                    </div>
                                 </div>
                                 <div class="col-xl-6 col-lg-5 col-md-5 text-start text-md-end mb-30">
                                     <div class="social-links">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div>
                                 </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--case-single-wrapper end-->
<?php
get_footer();